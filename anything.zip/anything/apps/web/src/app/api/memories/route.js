import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const memories = await sql`SELECT * FROM memories ORDER BY timestamp DESC`;
    return Response.json({ memories });
  } catch (error) {
    console.error("Error fetching memories:", error);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const { content, category } = await request.json();
    const result = await sql`
      INSERT INTO memories (content, category)
      VALUES (${content}, ${category || "personal"})
      RETURNING *
    `;

    await sql`
      INSERT INTO activity_log (action, reason, agent, impact)
      VALUES ('Memory Stored', ${`Category: ${category || "personal"}`}, 'recall', 'New memory added to long-term recall.')
    `;

    await sql`
      UPDATE agents SET last_action = NOW() WHERE type = 'recall'
    `;

    return Response.json({ memory: result[0] });
  } catch (error) {
    console.error("Error storing memory:", error);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
