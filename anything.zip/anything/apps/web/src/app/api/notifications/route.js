import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const notifications =
      await sql`SELECT * FROM notifications ORDER BY timestamp DESC LIMIT 50`;
    return Response.json({ notifications });
  } catch (error) {
    console.error("Error fetching notifications:", error);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const { type, title, body } = await request.json();

    if (type === "simulate_security") {
      const eventTypes = [
        {
          type: "Unknown Device Detected",
          description:
            "An unrecognized device attempted to connect to the home network.",
          severity: "medium",
        },
        {
          type: "Motion Detected",
          description:
            "Front door camera triggered motion alert at unusual hour.",
          severity: "high",
        },
        {
          type: "Login Attempt",
          description: "Failed login attempt from unknown IP address.",
          severity: "medium",
        },
        {
          type: "Perimeter Breach",
          description: "Backyard sensor triggered without scheduled entry.",
          severity: "high",
        },
      ];
      const picked = eventTypes[Math.floor(Math.random() * eventTypes.length)];

      await sql`
        INSERT INTO security_events (type, description, severity)
        VALUES (${picked.type}, ${picked.description}, ${picked.severity})
      `;

      const notifResult = await sql`
        INSERT INTO notifications (title, body, type)
        VALUES (${`⚠️ ${picked.type}`}, ${picked.description}, 'security')
        RETURNING *
      `;

      await sql`
        INSERT INTO activity_log (action, reason, agent, impact)
        VALUES ('Security Simulation', 'Pipeline test triggered by user.', 'security_family', ${`Simulated: ${picked.type}`})
      `;

      await sql`
        UPDATE agents SET last_action = NOW() WHERE type = 'security_family'
      `;

      return Response.json({ notification: notifResult[0], simulated: picked });
    }

    const result = await sql`
      INSERT INTO notifications (title, body, type)
      VALUES (${title || "Notification"}, ${body || ""}, ${type || "info"})
      RETURNING *
    `;

    return Response.json({ notification: result[0] });
  } catch (error) {
    console.error("Error creating notification:", error);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
