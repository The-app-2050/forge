import sql from "@/app/api/utils/sql";

const LOCAL_USER_ID = "forge-local-user-1";

export async function GET(request) {
  try {
    const rows =
      await sql`SELECT * FROM profiles WHERE user_id = ${LOCAL_USER_ID} LIMIT 1`;
    return Response.json({ profile: rows[0] || null });
  } catch (error) {
    console.error("Error fetching profile:", error);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const { name, location, preferred_style } = await request.json();
    const result = await sql`
      INSERT INTO profiles (user_id, name, location, preferred_style)
      VALUES (${LOCAL_USER_ID}, ${name}, ${location}, ${preferred_style})
      ON CONFLICT (user_id) 
      DO UPDATE SET 
        name = EXCLUDED.name,
        location = EXCLUDED.location,
        preferred_style = EXCLUDED.preferred_style
      RETURNING *
    `;
    return Response.json({ profile: result[0] });
  } catch (error) {
    console.error("Error updating profile:", error);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
