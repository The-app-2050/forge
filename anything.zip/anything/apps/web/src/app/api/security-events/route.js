import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const events =
      await sql`SELECT * FROM security_events ORDER BY timestamp DESC LIMIT 50`;
    return Response.json({ events });
  } catch (error) {
    console.error("Error fetching security events:", error);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const { type, description, severity } = await request.json();
    const result = await sql`
      INSERT INTO security_events (type, description, severity)
      VALUES (${type}, ${description}, ${severity || "low"})
      RETURNING *
    `;

    await sql`
      INSERT INTO activity_log (action, reason, agent, impact)
      VALUES ('Security Event Created', ${`New event: ${type}`}, 'security_family', 'Event logged for review.')
    `;

    return Response.json({ event: result[0] });
  } catch (error) {
    console.error("Error creating security event:", error);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function PATCH(request) {
  try {
    const { id, resolved } = await request.json();
    const result = await sql`
      UPDATE security_events SET resolved = ${resolved} WHERE id = ${id} RETURNING *
    `;

    if (result.length > 0) {
      await sql`
        INSERT INTO activity_log (action, reason, agent, impact)
        VALUES ('Security Event Resolved', ${`Event #${id} resolved.`}, 'security_family', 'Threat mitigated.')
      `;
    }

    return Response.json({ event: result[0] || null });
  } catch (error) {
    console.error("Error updating security event:", error);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
