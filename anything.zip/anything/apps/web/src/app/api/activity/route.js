import sql from "@/app/api/utils/sql";

// ---------------------------------------------------------
// 1. EXISTING LOGIC: Fetch the activity logs for the UI
// ---------------------------------------------------------
export async function GET(request) {
  try {
    const logs =
      await sql`SELECT * FROM activity_log ORDER BY timestamp DESC LIMIT 100`;
    return Response.json({ logs });
  } catch (error) {
    console.error("Error fetching activity logs:", error);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

// ---------------------------------------------------------
// 2. NEW LOGIC: The Nexus Command Receiver (Swarm Logic)
// ---------------------------------------------------------
export async function POST(request) {
  try {
    const { command } = await request.json();
    if (!command)
      return Response.json({ error: "Command required" }, { status: 400 });

    // A. Log the incoming Nexus command
    await sql`
      INSERT INTO activity_log (action, reason, agent, impact)
      VALUES ('Nexus Command Received', ${command}, 'orchestrator', 'Swarm logic parsing intent.')
    `;

    // B. Swarm Routing Logic (Keyword based routing for now)
    const steps = [];
    steps.push({
      agent: "orchestrator",
      text: `Parsing intent: "${command.substring(0, 30)}..."`,
    });

    const lowerCmd = command.toLowerCase();

    if (
      lowerCmd.includes("remember") ||
      lowerCmd.includes("save") ||
      lowerCmd.includes("store")
    ) {
      steps.push({
        agent: "recall",
        text: "Committing directive to long-term associative memory.",
      });
      await sql`UPDATE agents SET last_action = NOW() WHERE type = 'recall'`;
    }

    if (
      lowerCmd.includes("secure") ||
      lowerCmd.includes("lock") ||
      lowerCmd.includes("check")
    ) {
      steps.push({
        agent: "security_family",
        text: "Verifying encrypted local constraints and perimeter.",
      });
      await sql`UPDATE agents SET last_action = NOW() WHERE type = 'security_family'`;
    }

    if (
      lowerCmd.includes("email") ||
      lowerCmd.includes("message") ||
      lowerCmd.includes("tell") ||
      lowerCmd.includes("draft")
    ) {
      steps.push({
        agent: "communication",
        text: "Drafting outbound communications and setting tone.",
      });
      await sql`UPDATE agents SET last_action = NOW() WHERE type = 'communication'`;
    }

    if (
      lowerCmd.includes("sync") ||
      lowerCmd.includes("offline") ||
      lowerCmd.includes("backup")
    ) {
      steps.push({
        agent: "resilience",
        text: "Waking Resilience Agent. Prepping local SQLite enclave.",
      });
      await sql`UPDATE agents SET last_action = NOW() WHERE type = 'resilience'`;
    }

    steps.push({
      agent: "orchestrator",
      text: "Synthesis complete. Swarm tasks delegated and logged.",
    });
    await sql`UPDATE agents SET last_action = NOW() WHERE type = 'orchestrator'`;

    return Response.json({ success: true, log: steps });
  } catch (error) {
    console.error("Nexus Routing Error:", error);
    return Response.json({ error: "Nexus routing failure" }, { status: 500 });
  }
}