import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const agents = await sql`SELECT * FROM agents ORDER BY id ASC`;
    return Response.json({ agents });
  } catch (error) {
    console.error("Error fetching agents:", error);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
