import sql from "@/app/api/utils/sql";

const LOCAL_USER_ID = "forge-local-user-1";

export async function POST(request) {
  try {
    const body = await request.json();
    const command = body.command || "";

    // Check if we are handling a vision scan (looking for base64 signature)
    const isVision = command.includes("Vision Scan:");

    const profile =
      await sql`SELECT * FROM profiles WHERE user_id = ${LOCAL_USER_ID} LIMIT 1`;
    const userName = profile[0]?.name || "User";

    // Build messages array dynamically
    const messages = [
      {
        role: "system",
        content: `You are Forge Orchestrator. You help ${userName}. If provided an image, describe it concisely and suggest actions related to the user's business (dropshipping or event planning).`,
      },
    ];

    if (isVision) {
      // Structure for vision-enabled models
      messages.push({
        role: "user",
        content: [
          {
            type: "text",
            text: "Analyze this image and log relevant details for Forge OS.",
          },
          {
            type: "image_url",
            image_url: {
              url: `data:image/jpeg;base64,${
                command.split("base64,")[1] || "..."
              }`,
            },
          },
        ],
      });
    } else {
      messages.push({
        role: "user",
        content: `Generate a brief based on this context: ${command}`,
      });
    }

    const aiResponse = await fetch(
      `${process.env.NEXT_PUBLIC_CREATE_APP_URL}/integrations/chat-gpt`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages }),
      }
    );

    if (!aiResponse.ok) {
      const errorText = await aiResponse.text();
      console.error("AI API Error:", errorText);
      throw new Error(`AI Integration failed: ${aiResponse.status}`);
    }

    const data = await aiResponse.json();
    const result = data?.choices?.[0]?.message?.content || "Context processed.";

    return Response.json({ brief: result });
  } catch (error) {
    console.error("Orchestration error:", error);
    return Response.json({
      brief: "Vision Agent is recalibrating. Please try again.",
    });
  }
}