import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const { scenario } = await request.json();

    const memories =
      await sql`SELECT content FROM memories ORDER BY timestamp DESC LIMIT 3`;
    const memoryContext = memories.map((m) => m.content).join("; ");

    const aiResponse = await fetch(
      `${process.env.NEXT_PUBLIC_CREATE_APP_URL}/integrations/openai-o3/`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [
            {
              role: "system",
              content: `You are the Forge Communication Agent. Craft a thoughtful, professional, and human-sounding reply based on the scenario provided. Keep it concise (2-4 sentences). If relevant, use context from memories: ${memoryContext}`,
            },
            {
              role: "user",
              content: scenario,
            },
          ],
        }),
      },
    );

    if (!aiResponse.ok) {
      throw new Error("AI Integration failed");
    }

    const data = await aiResponse.json();
    const reply = data.choices[0].message.content;

    await sql`
      INSERT INTO activity_log (action, reason, agent, impact)
      VALUES ('Smart Reply Generated', ${`Scenario: ${scenario.substring(0, 100)}`}, 'communication', 'Reply crafted for user.')
    `;

    await sql`
      UPDATE agents SET last_action = NOW() WHERE type = 'communication'
    `;

    return Response.json({ reply });
  } catch (error) {
    console.error("Smart reply error:", error);
    return Response.json(
      { error: "Failed to generate reply" },
      { status: 500 },
    );
  }
}
