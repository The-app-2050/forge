import { View, Text, TouchableOpacity } from "react-native";
import { useRouter } from "expo-router";
import { Zap } from "lucide-react-native";
import { useInAppPurchase } from "@/utils/iap";

export default function UpgradeBanner() {
  const router = useRouter();
  const { isSubscribed, isReady } = useInAppPurchase();

  if (!isReady || isSubscribed) return null;

  return (
    <TouchableOpacity
      onPress={() => router.push("/paywall")}
      activeOpacity={0.85}
      style={{
        marginHorizontal: 16,
        backgroundColor: "rgba(59,130,246,0.12)",
        borderRadius: 14,
        paddingVertical: 12,
        paddingHorizontal: 16,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center",
        gap: 8,
        borderWidth: 1,
        borderColor: "rgba(59,130,246,0.25)",
      }}
    >
      <Zap size={16} color="#3B82F6" />
      <Text style={{ color: "#3B82F6", fontSize: 13, fontWeight: "700" }}>
        Unlock Forge Pro
      </Text>
    </TouchableOpacity>
  );
}
