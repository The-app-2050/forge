import { useState, useCallback, useRef } from "react";
import { Platform } from "react-native";

const getRevenueCatAPIKey = () => {
  if (process.env.EXPO_PUBLIC_CREATE_ENV === "DEVELOPMENT") {
    return process.env.EXPO_PUBLIC_REVENUE_CAT_TEST_STORE_API_KEY;
  }
  if (Platform.OS === "ios") {
    return process.env.EXPO_PUBLIC_REVENUE_CAT_APP_STORE_API_KEY;
  }
  if (Platform.OS === "android") {
    return process.env.EXPO_PUBLIC_REVENUE_CAT_PLAY_STORE_API_KEY;
  }
  return process.env.EXPO_PUBLIC_REVENUE_CAT_TEST_STORE_API_KEY;
};

export function useInAppPurchase() {
  const [isReady, setIsReady] = useState(false);
  const [offerings, setOfferings] = useState(null);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [isPurchasing, setIsPurchasing] = useState(false);
  const configured = useRef(false);

  const initiate = useCallback(async () => {
    try {
      const Purchases = (await import("react-native-purchases")).default;
      const apiKey = getRevenueCatAPIKey();

      if (!configured.current && apiKey) {
        Purchases.configure({ apiKey });
        configured.current = true;
      }

      // Try loading offerings with retries
      let retries = 0;
      let loadedOfferings = null;
      while (retries < 3 && !loadedOfferings) {
        try {
          loadedOfferings = await Purchases.getOfferings();
          if (loadedOfferings?.current) {
            setOfferings(loadedOfferings);
          }
        } catch (e) {
          retries++;
          if (retries < 3) {
            await new Promise((r) => setTimeout(r, 1500));
          }
        }
      }

      // Check subscription status
      try {
        const customerInfo = await Purchases.getCustomerInfo();
        const hasActive =
          Object.keys(customerInfo.entitlements.active).length > 0;
        setIsSubscribed(hasActive);
      } catch (e) {
        console.warn("Could not check subscription status:", e);
      }
    } catch (e) {
      console.warn("RevenueCat init skipped (not configured):", e.message);
    } finally {
      setIsReady(true);
    }
  }, []);

  const getAvailablePackages = useCallback(() => {
    if (!offerings?.current) return [];
    return offerings.current.availablePackages || [];
  }, [offerings]);

  const getAvailableSubscriptions = useCallback(() => {
    const packages = getAvailablePackages();
    return packages.filter((p) => p.packageType !== "CUSTOM");
  }, [getAvailablePackages]);

  const purchasePackage = useCallback(async ({ pkg }) => {
    try {
      setIsPurchasing(true);
      const Purchases = (await import("react-native-purchases")).default;
      const { customerInfo } = await Purchases.purchasePackage(pkg);
      const hasActive =
        Object.keys(customerInfo.entitlements.active).length > 0;
      setIsSubscribed(hasActive);
      return { success: true, customerInfo };
    } catch (e) {
      if (e.userCancelled) {
        return { success: false, cancelled: true };
      }
      console.error("Purchase error:", e);
      return { success: false, cancelled: false };
    } finally {
      setIsPurchasing(false);
    }
  }, []);

  const restorePurchases = useCallback(async () => {
    try {
      setIsPurchasing(true);
      const Purchases = (await import("react-native-purchases")).default;
      const customerInfo = await Purchases.restorePurchases();
      const hasActive =
        Object.keys(customerInfo.entitlements.active).length > 0;
      setIsSubscribed(hasActive);
      return { success: true, customerInfo };
    } catch (e) {
      console.error("Restore error:", e);
      return { success: false };
    } finally {
      setIsPurchasing(false);
    }
  }, []);

  return {
    isReady,
    offerings,
    isSubscribed,
    isPurchasing,
    initiate,
    getAvailablePackages,
    getAvailableSubscriptions,
    purchasePackage,
    restorePurchases,
  };
}
