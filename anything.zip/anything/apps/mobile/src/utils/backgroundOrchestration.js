export function setupBackgroundOrchestration() {
  let intervalId = null;

  // Run orchestration check every 15 minutes
  const runOrchestration = async () => {
    try {
      await fetch("/api/orchestrate", { method: "POST" });
    } catch (e) {
      // Silent fail — background task
    }
  };

  // Initial delay before first run (30 seconds)
  const timeoutId = setTimeout(() => {
    runOrchestration();
    intervalId = setInterval(runOrchestration, 15 * 60 * 1000);
  }, 30000);

  // Return cleanup function
  return () => {
    clearTimeout(timeoutId);
    if (intervalId) clearInterval(intervalId);
  };
}
