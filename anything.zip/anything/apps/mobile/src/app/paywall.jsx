import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  StyleSheet,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Shield, Brain, Users, X } from "lucide-react-native";
import { useInAppPurchase } from "@/utils/iap";
import { useRouter } from "expo-router";

export default function PaywallView() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const {
    getAvailablePackages,
    purchasePackage,
    isPurchasing,
    restorePurchases,
  } = useInAppPurchase();

  const packages = getAvailablePackages();

  const features = [
    {
      icon: <Shield size={20} color="#3B82F6" />,
      text: "Full Security Guardian",
    },
    {
      icon: <Brain size={20} color="#3B82F6" />,
      text: "Unlimited Recall Memory",
    },
    { icon: <Users size={20} color="#3B82F6" />, text: "Family Shared Agents" },
  ];

  const handlePurchase = async (pkg) => {
    const { success } = await purchasePackage({ pkg });
    if (success) {
      router.back();
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: "#000" }}>
      <View
        style={{
          paddingTop: insets.top + 20,
          paddingHorizontal: 20,
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <Text style={{ color: "#fff", fontSize: 24, fontWeight: "800" }}>
          Unlock Forge
        </Text>
        <TouchableOpacity onPress={() => router.back()}>
          <X size={24} color="#9CA3AF" />
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={{ padding: 24 }}>
        <Text style={{ color: "#9CA3AF", fontSize: 16, marginBottom: 32 }}>
          Power your life with elite agent collectives.
        </Text>

        <View style={{ marginBottom: 40 }}>
          {features.map((f, i) => (
            <View
              key={i}
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginBottom: 20,
              }}
            >
              <View
                style={{
                  width: 40,
                  height: 40,
                  borderRadius: 12,
                  backgroundColor: "rgba(59, 130, 246, 0.1)",
                  justifyContent: "center",
                  alignItems: "center",
                  marginRight: 16,
                }}
              >
                {f.icon}
              </View>
              <Text style={{ color: "#fff", fontSize: 16, fontWeight: "600" }}>
                {f.text}
              </Text>
            </View>
          ))}
        </View>

        <View style={{ gap: 16 }}>
          {packages.length > 0 ? (
            packages.map((pkg) => (
              <TouchableOpacity
                key={pkg.identifier}
                onPress={() => handlePurchase(pkg)}
                disabled={isPurchasing}
                style={{
                  backgroundColor: "#3B82F6",
                  borderRadius: 16,
                  padding: 20,
                  flexDirection: "row",
                  justifyContent: "space-between",
                  alignItems: "center",
                }}
              >
                <View>
                  <Text
                    style={{ color: "#fff", fontSize: 18, fontWeight: "700" }}
                  >
                    {pkg.product.title}
                  </Text>
                  <Text
                    style={{ color: "rgba(255, 255, 255, 0.8)", fontSize: 14 }}
                  >
                    {pkg.product.description}
                  </Text>
                </View>
                <Text
                  style={{ color: "#fff", fontSize: 18, fontWeight: "800" }}
                >
                  {pkg.product.priceString}
                </Text>
              </TouchableOpacity>
            ))
          ) : (
            <View style={{ padding: 40, alignItems: "center" }}>
              <ActivityIndicator color="#3B82F6" />
              <Text style={{ color: "#6B7280", marginTop: 12 }}>
                Loading packages...
              </Text>
            </View>
          )}
        </View>

        <TouchableOpacity
          onPress={() => restorePurchases()}
          style={{ marginTop: 32, alignSelf: "center" }}
        >
          <Text style={{ color: "#3B82F6", fontSize: 14, fontWeight: "600" }}>
            Restore Purchases
          </Text>
        </TouchableOpacity>
      </ScrollView>

      {isPurchasing && (
        <View
          style={{
            ...StyleSheet.absoluteFillObject,
            backgroundColor: "rgba(0,0,0,0.7)",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <ActivityIndicator size="large" color="#fff" />
        </View>
      )}
    </View>
  );
}
