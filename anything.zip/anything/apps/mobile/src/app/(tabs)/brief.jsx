import React, { useState } from "react";
import {
  View,
  TextInput,
  StyleSheet,
  Text,
  TouchableOpacity,
  ScrollView,
} from "react-native";

export default function BriefScreen() {
  const [command, setCommand] = useState("");

  return (
    <View style={styles.container}>
      {/* 1. The Nexus */}
      <View style={styles.nexus}>
        <TextInput
          style={styles.input}
          placeholder="Forge command..."
          placeholderTextColor="#444"
          value={command}
          onChangeText={setCommand}
        />
        <TouchableOpacity style={styles.sendButton}>
          <Text style={styles.sendText}>↑</Text>
        </TouchableOpacity>
      </View>

      {/* 2. Intake Row */}
      <View style={styles.intakeRow}>
        <TouchableOpacity style={styles.toolBtn}>
          <Text style={styles.btnText}>Camera</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.toolBtn}>
          <Text style={styles.btnText}>Message</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.toolBtn}>
          <Text style={styles.btnText}>Shield</Text>
        </TouchableOpacity>
      </View>

      {/* 3. Execution Feed */}
      <View style={styles.log}>
        <View style={styles.logHeader}>
          <View style={styles.dot} />
          <Text style={styles.logStatus}>Live Execution Feed</Text>
        </View>
      </View>

      {/* 4. Agent Collective Status */}
      <View style={styles.agentGrid}>
        <Text style={styles.gridLabel}>Agent Collective Status</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#000", padding: 15, paddingTop: 10 },

  // Nexus: Subtle border and glow
  nexus: {
    flexDirection: "row",
    backgroundColor: "#0a0a0a",
    padding: 12,
    borderRadius: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: "#222",
  },
  input: { flex: 1, color: "#fff", paddingHorizontal: 10, fontSize: 15 },
  sendButton: {
    backgroundColor: "#00ffcc",
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#00ffcc",
    shadowOpacity: 0.3,
    shadowRadius: 10,
  },
  sendText: { fontWeight: "bold", fontSize: 18, color: "#000" },

  // Intake Row: Sleek buttons
  intakeRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 12,
  },
  toolBtn: {
    backgroundColor: "#0a0a0a",
    paddingVertical: 14,
    borderRadius: 16,
    flex: 0.31,
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#222",
  },
  btnText: { color: "#888", fontSize: 13, fontWeight: "600" },

  // Feed: Darker, high-contrast
  log: {
    flex: 1,
    backgroundColor: "#050505",
    borderRadius: 20,
    padding: 20,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: "#1a1a1a",
  },
  logHeader: { flexDirection: "row", alignItems: "center", marginBottom: 10 },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: "#00ffcc",
    marginRight: 8,
  },
  logStatus: {
    color: "#00ffcc",
    fontSize: 13,
    fontWeight: "600",
    letterSpacing: 0.5,
  },

  // Agent Grid: Depth
  agentGrid: {
    height: 100,
    backgroundColor: "#0a0a0a",
    borderRadius: 20,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 10,
    borderWidth: 1,
    borderColor: "#222",
  },
  gridLabel: {
    color: "#444",
    fontSize: 13,
    fontWeight: "700",
    textTransform: "uppercase",
    letterSpacing: 1,
  },
});