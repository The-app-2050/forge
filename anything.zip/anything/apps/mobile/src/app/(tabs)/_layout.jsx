import { Tabs } from "expo-router";
import { Sunrise, Shield, Archive, Brain, Clock } from "lucide-react-native";
import { View } from "react-native";
import { useEffect } from "react";
import UpgradeBanner from "@/components/UpgradeBanner";
import { setupBackgroundOrchestration } from "@/utils/backgroundOrchestration";

export default function TabLayout() {
  useEffect(() => {
    const cleanupBg = setupBackgroundOrchestration();
    return () => cleanupBg();
  }, []);

  return (
    <View style={{ flex: 1 }}>
      <Tabs
        screenOptions={{
          headerShown: false,
          tabBarStyle: {
            backgroundColor: "#000000",
            borderTopWidth: 0,
            elevation: 0,
            shadowOpacity: 0,
            paddingBottom: 25,
          },
          tabBarActiveTintColor: "#3B82F6",
          tabBarInactiveTintColor: "#6B7280",
          tabBarLabelStyle: {
            fontSize: 10,
            fontWeight: "600",
          },
        }}
      >
        <Tabs.Screen
          name="brief"
          options={{
            title: "Brief",
            tabBarIcon: ({ color }) => <Sunrise size={24} color={color} />,
          }}
        />
        <Tabs.Screen
          name="security"
          options={{
            title: "Security",
            tabBarIcon: ({ color }) => <Shield size={24} color={color} />,
          }}
        />
        <Tabs.Screen
          name="vault"
          options={{
            title: "Vault",
            tabBarIcon: ({ color }) => <Archive size={24} color={color} />,
          }}
        />
        <Tabs.Screen
          name="recall"
          options={{
            title: "Recall",
            tabBarIcon: ({ color }) => <Brain size={24} color={color} />,
          }}
        />
        <Tabs.Screen
          name="activity"
          options={{
            title: "Activity",
            tabBarIcon: ({ color }) => <Clock size={24} color={color} />,
          }}
        />
      </Tabs>
      <View
        style={{
          position: "absolute",
          bottom: 82,
          left: 0,
          right: 0,
          pointerEvents: "box-none",
        }}
      >
        <UpgradeBanner />
      </View>
    </View>
  );
}
