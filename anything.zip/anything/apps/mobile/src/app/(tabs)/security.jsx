import { useState } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import {
  Shield,
  ShieldCheck,
  AlertTriangle,
  Zap,
  Camera,
  Home,
  RefreshCw,
} from "lucide-react-native";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

const THREAT_LEVELS = {
  0: { label: "SECURE", color: "#10B981", bg: "rgba(16,185,129,0.1)" },
  1: { label: "ELEVATED", color: "#F59E0B", bg: "rgba(245,158,11,0.1)" },
  2: { label: "CRITICAL", color: "#EF4444", bg: "rgba(239,68,68,0.1)" },
};

export default function SecurityDashboard() {
  const insets = useSafeAreaInsets();
  const queryClient = useQueryClient();

  const { data: securityData, isLoading } = useQuery({
    queryKey: ["security-events"],
    queryFn: async () => {
      const res = await fetch("/api/security-events");
      if (!res.ok) throw new Error("Failed to fetch security events");
      return res.json();
    },
    refetchInterval: 15000,
  });

  const events = securityData?.events || [];
  const unresolvedCount = events.filter((e) => !e.resolved).length;
  const threatLevel = unresolvedCount === 0 ? 0 : unresolvedCount < 3 ? 1 : 2;
  const threat = THREAT_LEVELS[threatLevel];

  const simulateMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/notifications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: "simulate_security" }),
      });
      if (!res.ok) throw new Error("Simulation failed");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["security-events"] });
      queryClient.invalidateQueries({ queryKey: ["notifications"] });
      queryClient.invalidateQueries({ queryKey: ["activity"] });
    },
  });

  const resolveMutation = useMutation({
    mutationFn: async (id) => {
      const res = await fetch("/api/security-events", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, resolved: true }),
      });
      if (!res.ok) throw new Error("Resolve failed");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["security-events"] });
      queryClient.invalidateQueries({ queryKey: ["activity"] });
    },
  });

  return (
    <View style={{ flex: 1, backgroundColor: "#000" }}>
      <LinearGradient
        colors={["rgba(239,68,68,0.15)", "transparent"]}
        style={{ position: "absolute", left: 0, right: 0, top: 0, height: 350 }}
        pointerEvents="none"
      />
      <View
        style={{
          paddingTop: insets.top + 20,
          paddingHorizontal: 20,
          marginBottom: 20,
        }}
      >
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <View>
            <Text style={{ color: "#fff", fontSize: 32, fontWeight: "800" }}>
              Security
            </Text>
            <Text style={{ color: "#9CA3AF", fontSize: 14, marginTop: 4 }}>
              Guardian agent active.
            </Text>
          </View>
          <TouchableOpacity
            onPress={() =>
              queryClient.invalidateQueries({ queryKey: ["security-events"] })
            }
            style={{
              width: 44,
              height: 44,
              borderRadius: 22,
              backgroundColor: "#111827",
              justifyContent: "center",
              alignItems: "center",
              borderWidth: 1,
              borderColor: "rgba(239,68,68,0.3)",
            }}
          >
            <RefreshCw size={18} color="#EF4444" />
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 160 }}
        showsVerticalScrollIndicator={false}
      >
        <View
          style={{
            backgroundColor: threat.bg,
            borderRadius: 24,
            padding: 24,
            borderWidth: 1,
            borderColor: `${threat.color}44`,
            marginBottom: 20,
            flexDirection: "row",
            alignItems: "center",
            gap: 16,
          }}
        >
          {threatLevel === 0 ? (
            <ShieldCheck size={48} color={threat.color} />
          ) : (
            <AlertTriangle size={48} color={threat.color} />
          )}
          <View style={{ flex: 1 }}>
            <Text
              style={{
                color: threat.color,
                fontSize: 11,
                fontWeight: "800",
                letterSpacing: 1.5,
                marginBottom: 4,
              }}
            >
              THREAT LEVEL · {threat.label}
            </Text>
            <Text style={{ color: "#fff", fontSize: 20, fontWeight: "700" }}>
              {unresolvedCount === 0
                ? "All systems secure"
                : `${unresolvedCount} active event${unresolvedCount !== 1 ? "s" : ""}`}
            </Text>
            <Text style={{ color: "#9CA3AF", fontSize: 13, marginTop: 4 }}>
              {isLoading ? "Scanning..." : `${events.length} total logged`}
            </Text>
          </View>
        </View>

        <Text
          style={{
            color: "#fff",
            fontSize: 16,
            fontWeight: "700",
            marginBottom: 14,
          }}
        >
          Monitored Zones
        </Text>
        <View style={{ flexDirection: "row", gap: 12, marginBottom: 24 }}>
          {[
            { icon: Home, label: "Front Door", status: "Clear" },
            { icon: Camera, label: "Backyard", status: "Clear" },
            { icon: Zap, label: "Network", status: "Online" },
          ].map((zone) => {
            const ZoneIcon = zone.icon;
            return (
              <View
                key={zone.label}
                style={{
                  flex: 1,
                  backgroundColor: "rgba(255,255,255,0.04)",
                  borderRadius: 16,
                  padding: 14,
                  alignItems: "center",
                  borderWidth: 1,
                  borderColor: "rgba(255,255,255,0.08)",
                }}
              >
                <ZoneIcon
                  size={22}
                  color="#10B981"
                  style={{ marginBottom: 8 }}
                />
                <Text
                  style={{
                    color: "#fff",
                    fontSize: 12,
                    fontWeight: "700",
                    textAlign: "center",
                  }}
                >
                  {zone.label}
                </Text>
                <Text style={{ color: "#10B981", fontSize: 11, marginTop: 4 }}>
                  {zone.status}
                </Text>
              </View>
            );
          })}
        </View>

        <Text
          style={{
            color: "#fff",
            fontSize: 16,
            fontWeight: "700",
            marginBottom: 14,
          }}
        >
          Pipeline Test
        </Text>
        <TouchableOpacity
          onPress={() => simulateMutation.mutate()}
          disabled={simulateMutation.isPending}
          style={{
            backgroundColor: simulateMutation.isPending
              ? "#1F2937"
              : "rgba(239,68,68,0.15)",
            borderRadius: 18,
            padding: 20,
            borderWidth: 1,
            borderColor: "rgba(239,68,68,0.4)",
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "center",
            gap: 12,
            marginBottom: 28,
          }}
        >
          {simulateMutation.isPending ? (
            <ActivityIndicator size="small" color="#EF4444" />
          ) : (
            <Shield size={20} color="#EF4444" />
          )}
          <View>
            <Text
              style={{
                color: simulateMutation.isPending ? "#6B7280" : "#EF4444",
                fontSize: 16,
                fontWeight: "700",
              }}
            >
              {simulateMutation.isPending
                ? "Simulating…"
                : "Simulate Security Event"}
            </Text>
            <Text style={{ color: "#6B7280", fontSize: 12, marginTop: 2 }}>
              Notification → Vault → Activity Log
            </Text>
          </View>
        </TouchableOpacity>

        <Text
          style={{
            color: "#fff",
            fontSize: 16,
            fontWeight: "700",
            marginBottom: 14,
          }}
        >
          Security Events
        </Text>
        {isLoading ? (
          <View style={{ padding: 40, alignItems: "center" }}>
            <ActivityIndicator size="large" color="#EF4444" />
          </View>
        ) : events.length === 0 ? (
          <View
            style={{
              backgroundColor: "rgba(255,255,255,0.03)",
              borderRadius: 16,
              padding: 32,
              alignItems: "center",
              borderWidth: 1,
              borderColor: "rgba(255,255,255,0.06)",
            }}
          >
            <ShieldCheck
              size={40}
              color="#10B981"
              style={{ marginBottom: 12 }}
            />
            <Text style={{ color: "#9CA3AF", textAlign: "center" }}>
              No events recorded. Your perimeter is clean.
            </Text>
          </View>
        ) : (
          events.map((event) => (
            <View
              key={event.id}
              style={{
                backgroundColor: event.resolved
                  ? "rgba(255,255,255,0.02)"
                  : "rgba(239,68,68,0.06)",
                borderRadius: 16,
                padding: 16,
                marginBottom: 12,
                borderWidth: 1,
                borderColor: event.resolved
                  ? "rgba(255,255,255,0.06)"
                  : "rgba(239,68,68,0.25)",
              }}
            >
              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "space-between",
                  alignItems: "flex-start",
                  marginBottom: 6,
                }}
              >
                <Text
                  style={{
                    color: event.resolved ? "#9CA3AF" : "#fff",
                    fontSize: 15,
                    fontWeight: "700",
                    flex: 1,
                    marginRight: 8,
                  }}
                >
                  {event.type}
                </Text>
                {!event.resolved && (
                  <TouchableOpacity
                    onPress={() => resolveMutation.mutate(event.id)}
                    disabled={resolveMutation.isPending}
                    style={{
                      backgroundColor: "rgba(16,185,129,0.15)",
                      paddingHorizontal: 10,
                      paddingVertical: 4,
                      borderRadius: 8,
                      borderWidth: 1,
                      borderColor: "rgba(16,185,129,0.3)",
                    }}
                  >
                    <Text
                      style={{
                        color: "#10B981",
                        fontSize: 11,
                        fontWeight: "700",
                      }}
                    >
                      RESOLVE
                    </Text>
                  </TouchableOpacity>
                )}
              </View>
              <Text
                style={{
                  color: event.resolved ? "#6B7280" : "#9CA3AF",
                  fontSize: 13,
                  lineHeight: 18,
                  marginBottom: 8,
                }}
              >
                {event.description}
              </Text>
              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "space-between",
                  alignItems: "center",
                }}
              >
                <Text style={{ color: "#4B5563", fontSize: 11 }}>
                  {new Date(event.timestamp).toLocaleString()}
                </Text>
                <View
                  style={{
                    backgroundColor: event.resolved
                      ? "rgba(16,185,129,0.1)"
                      : "rgba(239,68,68,0.1)",
                    paddingHorizontal: 8,
                    paddingVertical: 2,
                    borderRadius: 6,
                  }}
                >
                  <Text
                    style={{
                      color: event.resolved ? "#10B981" : "#EF4444",
                      fontSize: 10,
                      fontWeight: "700",
                    }}
                  >
                    {event.resolved ? "RESOLVED" : "ACTIVE"}
                  </Text>
                </View>
              </View>
            </View>
          ))
        )}
      </ScrollView>
    </View>
  );
}
