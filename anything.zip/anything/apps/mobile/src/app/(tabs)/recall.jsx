import { useState, useCallback } from "react";
import {
  View,
  Text,
  FlatList,
  RefreshControl,
  TouchableOpacity,
  TextInput,
  Modal,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Brain, Plus, X, Check, Tag } from "lucide-react-native";

const CATEGORIES = [
  { key: "personal", label: "Personal", color: "#3B82F6" },
  { key: "work", label: "Work", color: "#8B5CF6" },
  { key: "health", label: "Health", color: "#10B981" },
  { key: "family", label: "Family", color: "#F59E0B" },
  { key: "security", label: "Security", color: "#EF4444" },
  { key: "preference", label: "Preference", color: "#EC4899" },
  { key: "aversion", label: "Aversion", color: "#E11D48" },
  { key: "system", label: "System", color: "#6B7280" },
];

function categoryMeta(key) {
  return (
    CATEGORIES.find((c) => c.key === key) || {
      key,
      label: key,
      color: "#3B82F6",
    }
  );
}

export default function RecallView() {
  const insets = useSafeAreaInsets();
  const queryClient = useQueryClient();
  const [modalVisible, setModalVisible] = useState(false);
  const [content, setContent] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("personal");

  const { data, isLoading, refetch } = useQuery({
    queryKey: ["memories"],
    queryFn: async () => {
      const res = await fetch("/api/memories");
      if (!res.ok) throw new Error("Failed to fetch memories");
      return res.json();
    },
  });

  const addMutation = useMutation({
    mutationFn: async ({ content, category }) => {
      const res = await fetch("/api/memories", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content, category }),
      });
      if (!res.ok) throw new Error("Failed to store memory");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["memories"] });
      queryClient.invalidateQueries({ queryKey: ["activity"] });
      setModalVisible(false);
      setContent("");
      setSelectedCategory("personal");
    },
  });

  const handleSave = useCallback(() => {
    if (!content.trim() || addMutation.isPending) return;
    addMutation.mutate({ content: content.trim(), category: selectedCategory });
  }, [content, selectedCategory, addMutation]);

  const renderItem = ({ item }) => {
    const meta = categoryMeta(item.category);
    return (
      <View
        style={{
          padding: 16,
          backgroundColor: "rgba(255,255,255,0.04)",
          borderRadius: 16,
          marginBottom: 12,
          borderWidth: 1,
          borderColor: `${meta.color}22`,
        }}
      >
        <Text
          style={{
            color: "#E5E7EB",
            fontSize: 15,
            lineHeight: 22,
            marginBottom: 12,
          }}
        >
          {item.content}
        </Text>
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              gap: 5,
              backgroundColor: `${meta.color}18`,
              paddingHorizontal: 8,
              paddingVertical: 3,
              borderRadius: 6,
            }}
          >
            <Tag size={10} color={meta.color} />
            <Text
              style={{
                color: meta.color,
                fontSize: 10,
                fontWeight: "700",
                textTransform: "uppercase",
              }}
            >
              {meta.label}
            </Text>
          </View>
          <Text style={{ color: "#6B7280", fontSize: 12 }}>
            {new Date(item.timestamp).toLocaleDateString()}
          </Text>
        </View>
      </View>
    );
  };

  return (
    <View style={{ flex: 1, backgroundColor: "#000" }}>
      <View
        style={{
          paddingTop: insets.top + 20,
          paddingHorizontal: 20,
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
          marginBottom: 20,
        }}
      >
        <View>
          <Text style={{ color: "#fff", fontSize: 32, fontWeight: "800" }}>
            Recall
          </Text>
          <Text style={{ color: "#9CA3AF", fontSize: 14, marginTop: 4 }}>
            Long-term associative memory.
          </Text>
        </View>
        <TouchableOpacity
          onPress={() => setModalVisible(true)}
          style={{
            width: 44,
            height: 44,
            borderRadius: 22,
            backgroundColor: "rgba(16,185,129,0.15)",
            justifyContent: "center",
            alignItems: "center",
            borderWidth: 1,
            borderColor: "rgba(16,185,129,0.35)",
          }}
        >
          <Plus size={22} color="#10B981" />
        </TouchableOpacity>
      </View>

      <FlatList
        data={data?.memories || []}
        renderItem={renderItem}
        keyExtractor={(item) => String(item.id)}
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 160 }}
        ListEmptyComponent={
          !isLoading ? (
            <View style={{ alignItems: "center", marginTop: 80 }}>
              <Brain size={52} color="#1F2937" />
              <Text style={{ color: "#4B5563", marginTop: 16, fontSize: 15 }}>
                No memories yet.
              </Text>
              <TouchableOpacity
                onPress={() => setModalVisible(true)}
                style={{
                  marginTop: 20,
                  backgroundColor: "rgba(16,185,129,0.12)",
                  paddingHorizontal: 20,
                  paddingVertical: 10,
                  borderRadius: 12,
                  borderWidth: 1,
                  borderColor: "rgba(16,185,129,0.3)",
                }}
              >
                <Text
                  style={{ color: "#10B981", fontSize: 14, fontWeight: "700" }}
                >
                  + Add First Memory
                </Text>
              </TouchableOpacity>
            </View>
          ) : null
        }
        refreshControl={
          <RefreshControl
            refreshing={isLoading}
            onRefresh={refetch}
            tintColor="#10B981"
          />
        }
      />

      <Modal
        visible={modalVisible}
        animationType="slide"
        transparent
        onRequestClose={() => setModalVisible(false)}
      >
        <KeyboardAvoidingView
          behavior={Platform.OS === "ios" ? "padding" : "height"}
          style={{ flex: 1 }}
        >
          <View
            style={{
              flex: 1,
              backgroundColor: "rgba(0,0,0,0.7)",
              justifyContent: "flex-end",
            }}
          >
            <View
              style={{
                backgroundColor: "#111827",
                borderTopLeftRadius: 28,
                borderTopRightRadius: 28,
                padding: 24,
                paddingBottom: insets.bottom + 24,
              }}
            >
              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "space-between",
                  alignItems: "center",
                  marginBottom: 20,
                }}
              >
                <Text
                  style={{ color: "#fff", fontSize: 20, fontWeight: "800" }}
                >
                  New Memory
                </Text>
                <TouchableOpacity onPress={() => setModalVisible(false)}>
                  <X size={22} color="#6B7280" />
                </TouchableOpacity>
              </View>

              <TextInput
                value={content}
                onChangeText={setContent}
                placeholder="What should Forge remember?"
                placeholderTextColor="#4B5563"
                multiline
                autoFocus
                style={{
                  color: "#fff",
                  fontSize: 16,
                  backgroundColor: "rgba(255,255,255,0.06)",
                  borderRadius: 14,
                  padding: 16,
                  lineHeight: 22,
                  maxHeight: 130,
                  borderWidth: 1,
                  borderColor: "rgba(255,255,255,0.1)",
                  marginBottom: 18,
                }}
              />

              <Text
                style={{
                  color: "#9CA3AF",
                  fontSize: 12,
                  fontWeight: "700",
                  letterSpacing: 0.8,
                  marginBottom: 10,
                }}
              >
                CATEGORY
              </Text>
              <View
                style={{
                  flexDirection: "row",
                  flexWrap: "wrap",
                  gap: 8,
                  marginBottom: 24,
                }}
              >
                {CATEGORIES.map((cat) => {
                  const isSelected = selectedCategory === cat.key;
                  return (
                    <TouchableOpacity
                      key={cat.key}
                      onPress={() => setSelectedCategory(cat.key)}
                      style={{
                        paddingHorizontal: 12,
                        paddingVertical: 6,
                        borderRadius: 10,
                        backgroundColor: isSelected
                          ? `${cat.color}25`
                          : "rgba(255,255,255,0.05)",
                        borderWidth: 1,
                        borderColor: isSelected
                          ? cat.color
                          : "rgba(255,255,255,0.1)",
                        flexDirection: "row",
                        alignItems: "center",
                        gap: 5,
                      }}
                    >
                      {isSelected && <Check size={11} color={cat.color} />}
                      <Text
                        style={{
                          color: isSelected ? cat.color : "#9CA3AF",
                          fontSize: 13,
                          fontWeight: isSelected ? "700" : "500",
                        }}
                      >
                        {cat.label}
                      </Text>
                    </TouchableOpacity>
                  );
                })}
              </View>

              <TouchableOpacity
                onPress={handleSave}
                disabled={!content.trim() || addMutation.isPending}
                style={{
                  height: 56,
                  borderRadius: 16,
                  backgroundColor:
                    content.trim() && !addMutation.isPending
                      ? "#10B981"
                      : "#1F2937",
                  justifyContent: "center",
                  alignItems: "center",
                  flexDirection: "row",
                  gap: 8,
                }}
              >
                {addMutation.isPending ? (
                  <ActivityIndicator size="small" color="#10B981" />
                ) : (
                  <Text
                    style={{
                      color: content.trim() ? "#fff" : "#4B5563",
                      fontSize: 16,
                      fontWeight: "700",
                    }}
                  >
                    Save Memory
                  </Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </View>
  );
}
