import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Archive, Bell, BellOff, Check } from "lucide-react-native";

export default function VaultView() {
  const insets = useSafeAreaInsets();
  const queryClient = useQueryClient();

  const { data, isLoading } = useQuery({
    queryKey: ["notifications"],
    queryFn: async () => {
      const res = await fetch("/api/notifications");
      if (!res.ok) throw new Error("Failed to fetch notifications");
      return res.json();
    },
    refetchInterval: 10000,
  });

  const notifications = data?.notifications || [];
  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <View style={{ flex: 1, backgroundColor: "#000" }}>
      <View
        style={{
          paddingTop: insets.top + 20,
          paddingHorizontal: 20,
          marginBottom: 20,
        }}
      >
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <View>
            <Text style={{ color: "#fff", fontSize: 32, fontWeight: "800" }}>
              Vault
            </Text>
            <Text style={{ color: "#9CA3AF", fontSize: 14, marginTop: 4 }}>
              {unreadCount > 0
                ? `${unreadCount} unread notification${unreadCount !== 1 ? "s" : ""}`
                : "All caught up."}
            </Text>
          </View>
          <View
            style={{
              width: 44,
              height: 44,
              borderRadius: 22,
              backgroundColor:
                unreadCount > 0 ? "rgba(245,158,11,0.15)" : "#111827",
              justifyContent: "center",
              alignItems: "center",
              borderWidth: 1,
              borderColor:
                unreadCount > 0
                  ? "rgba(245,158,11,0.35)"
                  : "rgba(255,255,255,0.08)",
            }}
          >
            {unreadCount > 0 ? (
              <Bell size={20} color="#F59E0B" />
            ) : (
              <BellOff size={20} color="#6B7280" />
            )}
          </View>
        </View>
      </View>

      <ScrollView
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 160 }}
        showsVerticalScrollIndicator={false}
      >
        {isLoading ? (
          <View style={{ padding: 40, alignItems: "center" }}>
            <ActivityIndicator size="large" color="#F59E0B" />
          </View>
        ) : notifications.length === 0 ? (
          <View
            style={{
              backgroundColor: "rgba(255,255,255,0.03)",
              borderRadius: 16,
              padding: 40,
              alignItems: "center",
              borderWidth: 1,
              borderColor: "rgba(255,255,255,0.06)",
              marginTop: 40,
            }}
          >
            <Archive size={44} color="#1F2937" style={{ marginBottom: 12 }} />
            <Text
              style={{ color: "#4B5563", fontSize: 15, textAlign: "center" }}
            >
              No notifications yet. Your agents will surface alerts here.
            </Text>
          </View>
        ) : (
          notifications.map((notif) => {
            const isSecurityType = notif.type === "security";
            const accentColor = isSecurityType ? "#EF4444" : "#F59E0B";

            return (
              <View
                key={notif.id}
                style={{
                  backgroundColor: notif.read
                    ? "rgba(255,255,255,0.02)"
                    : `${accentColor}0D`,
                  borderRadius: 16,
                  padding: 16,
                  marginBottom: 12,
                  borderWidth: 1,
                  borderColor: notif.read
                    ? "rgba(255,255,255,0.06)"
                    : `${accentColor}33`,
                }}
              >
                <View
                  style={{
                    flexDirection: "row",
                    justifyContent: "space-between",
                    alignItems: "flex-start",
                    marginBottom: 6,
                  }}
                >
                  <Text
                    style={{
                      color: notif.read ? "#9CA3AF" : "#fff",
                      fontSize: 15,
                      fontWeight: "700",
                      flex: 1,
                      marginRight: 8,
                    }}
                    numberOfLines={2}
                  >
                    {notif.title}
                  </Text>
                  {!notif.read && (
                    <View
                      style={{
                        width: 8,
                        height: 8,
                        borderRadius: 4,
                        backgroundColor: accentColor,
                        marginTop: 6,
                      }}
                    />
                  )}
                </View>
                {notif.body ? (
                  <Text
                    style={{
                      color: notif.read ? "#6B7280" : "#9CA3AF",
                      fontSize: 13,
                      lineHeight: 18,
                      marginBottom: 8,
                    }}
                  >
                    {notif.body}
                  </Text>
                ) : null}
                <View
                  style={{
                    flexDirection: "row",
                    justifyContent: "space-between",
                    alignItems: "center",
                  }}
                >
                  <Text style={{ color: "#4B5563", fontSize: 11 }}>
                    {new Date(notif.timestamp).toLocaleString()}
                  </Text>
                  <View
                    style={{
                      backgroundColor: isSecurityType
                        ? "rgba(239,68,68,0.1)"
                        : "rgba(245,158,11,0.1)",
                      paddingHorizontal: 8,
                      paddingVertical: 2,
                      borderRadius: 6,
                    }}
                  >
                    <Text
                      style={{
                        color: accentColor,
                        fontSize: 10,
                        fontWeight: "700",
                        textTransform: "uppercase",
                      }}
                    >
                      {notif.type || "info"}
                    </Text>
                  </View>
                </View>
              </View>
            );
          })
        )}
      </ScrollView>
    </View>
  );
}
