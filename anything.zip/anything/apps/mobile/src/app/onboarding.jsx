import { useState, useCallback, useRef } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  Animated,
  Platform,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Cpu, ArrowRight } from "lucide-react-native";
import KeyboardAvoidingAnimatedView from "@/components/KeyboardAvoidingAnimatedView";

export default function OnboardingScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const queryClient = useQueryClient();
  const [name, setName] = useState("");
  const [location, setLocation] = useState("");
  const [step, setStep] = useState(0);

  const focusedPadding = 12;
  const paddingAnimation = useRef(
    new Animated.Value(insets.bottom + focusedPadding),
  ).current;

  const animateTo = (value) => {
    Animated.timing(paddingAnimation, {
      toValue: value,
      duration: 200,
      useNativeDriver: false,
    }).start();
  };

  const handleInputFocus = () => {
    if (Platform.OS === "web") return;
    animateTo(focusedPadding);
  };

  const handleInputBlur = () => {
    if (Platform.OS === "web") return;
    animateTo(insets.bottom + focusedPadding);
  };

  const profileMutation = useMutation({
    mutationFn: async ({ name, location }) => {
      const res = await fetch("/api/profile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, location, preferred_style: "default" }),
      });
      if (!res.ok) throw new Error("Failed to save profile");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["profile"] });
      router.replace("/(tabs)/brief");
    },
  });

  const handleContinue = useCallback(() => {
    if (step === 0 && name.trim()) {
      setStep(1);
    } else if (step === 1 && location.trim()) {
      profileMutation.mutate({ name: name.trim(), location: location.trim() });
    }
  }, [step, name, location, profileMutation]);

  return (
    <KeyboardAvoidingAnimatedView style={{ flex: 1 }} behavior="padding">
      <View style={{ flex: 1, backgroundColor: "#000" }}>
        <View
          style={{
            flex: 1,
            paddingTop: insets.top + 60,
            paddingHorizontal: 28,
          }}
        >
          <View
            style={{
              width: 56,
              height: 56,
              borderRadius: 16,
              backgroundColor: "rgba(59,130,246,0.15)",
              justifyContent: "center",
              alignItems: "center",
              marginBottom: 32,
            }}
          >
            <Cpu size={28} color="#3B82F6" />
          </View>

          <Text
            style={{
              color: "#fff",
              fontSize: 34,
              fontWeight: "800",
              marginBottom: 12,
            }}
          >
            {step === 0 ? "Welcome to Forge" : "Where are you?"}
          </Text>
          <Text
            style={{
              color: "#9CA3AF",
              fontSize: 16,
              lineHeight: 24,
              marginBottom: 40,
            }}
          >
            {step === 0
              ? "Your personal AI operating system. Let's get you set up."
              : "This helps your agents deliver location-aware intelligence."}
          </Text>

          {step === 0 ? (
            <TextInput
              value={name}
              onChangeText={setName}
              placeholder="Your first name"
              placeholderTextColor="#4B5563"
              autoFocus
              onFocus={handleInputFocus}
              onBlur={handleInputBlur}
              style={{
                color: "#fff",
                fontSize: 20,
                backgroundColor: "rgba(255,255,255,0.06)",
                borderRadius: 16,
                padding: 18,
                borderWidth: 1,
                borderColor: "rgba(59,130,246,0.3)",
              }}
            />
          ) : (
            <TextInput
              value={location}
              onChangeText={setLocation}
              placeholder="City or region"
              placeholderTextColor="#4B5563"
              autoFocus
              onFocus={handleInputFocus}
              onBlur={handleInputBlur}
              style={{
                color: "#fff",
                fontSize: 20,
                backgroundColor: "rgba(255,255,255,0.06)",
                borderRadius: 16,
                padding: 18,
                borderWidth: 1,
                borderColor: "rgba(59,130,246,0.3)",
              }}
            />
          )}
        </View>

        <Animated.View
          style={{ paddingHorizontal: 28, paddingBottom: paddingAnimation }}
        >
          <TouchableOpacity
            onPress={handleContinue}
            disabled={
              (step === 0 && !name.trim()) ||
              (step === 1 && !location.trim()) ||
              profileMutation.isPending
            }
            style={{
              height: 58,
              borderRadius: 16,
              backgroundColor:
                (step === 0 && name.trim()) || (step === 1 && location.trim())
                  ? "#3B82F6"
                  : "#1F2937",
              justifyContent: "center",
              alignItems: "center",
              flexDirection: "row",
              gap: 10,
            }}
          >
            {profileMutation.isPending ? (
              <ActivityIndicator size="small" color="#fff" />
            ) : (
              <>
                <Text
                  style={{
                    color:
                      (step === 0 && name.trim()) ||
                      (step === 1 && location.trim())
                        ? "#fff"
                        : "#4B5563",
                    fontSize: 17,
                    fontWeight: "700",
                  }}
                >
                  {step === 0 ? "Continue" : "Launch Forge"}
                </Text>
                <ArrowRight
                  size={18}
                  color={
                    (step === 0 && name.trim()) ||
                    (step === 1 && location.trim())
                      ? "#fff"
                      : "#4B5563"
                  }
                />
              </>
            )}
          </TouchableOpacity>
        </Animated.View>
      </View>
    </KeyboardAvoidingAnimatedView>
  );
}
