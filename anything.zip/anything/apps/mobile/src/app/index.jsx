import { useEffect } from "react";
import { useRouter } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import { View, ActivityIndicator, Text } from "react-native";

export default function Index() {
  const router = useRouter();

  const { data, isLoading, isError } = useQuery({
    queryKey: ["profile"],
    queryFn: async () => {
      const res = await fetch("/api/profile");
      if (!res.ok) throw new Error("Failed to fetch profile");
      return res.json();
    },
    retry: 2,
    staleTime: 0,
  });

  useEffect(() => {
    if (isLoading) return;

    if (isError) {
      router.replace("/(tabs)/brief");
      return;
    }

    if (!data?.profile) {
      router.replace("/onboarding");
    } else {
      router.replace("/(tabs)/brief");
    }
  }, [isLoading, isError, data, router]);

  return (
    <View
      style={{
        flex: 1,
        backgroundColor: "#000",
        justifyContent: "center",
        alignItems: "center",
        gap: 16,
      }}
    >
      <ActivityIndicator size="large" color="#3B82F6" />
      <Text style={{ color: "#4B5563", fontSize: 14 }}>
        Initializing Forge…
      </Text>
    </View>
  );
}
